#version 300 es
precision highp float;

layout(location = 0) in vec2 a_position;
layout(location = 1) in float a_bounceCount;
layout(location = 2) in float a_distance;

uniform mat4 u_mvpMatrix;
uniform float u_time;

out float v_bounceCount;
out float v_distance;
out float v_alpha;

void main() {
    gl_Position = u_mvpMatrix * vec4(a_position, 0.0, 1.0);
    v_bounceCount = a_bounceCount;
    v_distance = a_distance;
    
    // Pulse effect for active segment
    float pulse = sin(u_time * 3.0 + a_distance * 0.5) * 0.3 + 0.7;
    v_alpha = pulse;
}
