#version 300 es
precision highp float;

layout(location = 0) in vec2 a_position;
uniform mat4 u_mvpMatrix;
uniform float u_radius;

out vec2 v_texCoord;

void main() {
    gl_Position = u_mvpMatrix * vec4(a_position * u_radius, 0.0, 1.0);
    v_texCoord = a_position;
}
