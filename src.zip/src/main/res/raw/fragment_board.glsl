#version 300 es
precision highp float;
out vec4 fragColor;
void main() {
    fragColor = vec4(0.2, 0.1, 0.05, 1.0); // Brown board
}
