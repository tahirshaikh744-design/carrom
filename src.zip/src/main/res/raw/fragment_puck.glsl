#version 300 es
precision highp float;

in vec2 v_texCoord;
out vec4 fragColor;

uniform vec4 u_color;

void main() {
    float dist = length(v_texCoord);
    if (dist > 1.0) discard;
    
    // Simple shading
    float shade = 1.0 - dist * 0.3;
    fragColor = vec4(u_color.rgb * shade, u_color.a);
}
