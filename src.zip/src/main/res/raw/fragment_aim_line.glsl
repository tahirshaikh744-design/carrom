#version 300 es
precision highp float;

in float v_bounceCount;
in float v_distance;
in float v_alpha;

out vec4 fragColor;

uniform vec4 u_baseColor;
uniform float u_dashSize;
uniform float u_gapSize;

void main() {
    // Dashed line pattern
    float pattern = mod(v_distance, u_dashSize + u_gapSize);
    float dashAlpha = pattern < u_dashSize ? 1.0 : 0.0;
    
    // Color based on bounce count
    vec3 color;
    if (v_bounceCount < 0.5) {
        color = vec3(0.0, 1.0, 0.5); // Cyan-green: direct shot
    } else if (v_bounceCount < 1.5) {
        color = vec3(1.0, 0.8, 0.0); // Yellow: 1 bounce
    } else if (v_bounceCount < 2.5) {
        color = vec3(1.0, 0.4, 0.0); // Orange: 2 bounces
    } else {
        color = vec3(1.0, 0.0, 0.2); // Red: 3+ bounces (risky)
    }
    
    // Fade after bounces
    float fade = 1.0 - (v_bounceCount * 0.15);
    
    // Glow effect
    float glow = exp(-v_distance * 0.02) * 0.3;
    
    fragColor = vec4(color + glow, (dashAlpha * fade * u_baseColor.a * v_alpha));
}
