package com.carrom.game.android.gl

import android.opengl.GLES30

class ShaderProgram(val programId: Int) {
    fun use() {
        GLES30.glUseProgram(programId)
    }

    fun getUniformLocation(name: String): Int {
        return GLES30.glGetUniformLocation(programId, name)
    }

    fun getAttribLocation(name: String): Int {
        return GLES30.glGetAttribLocation(programId, name)
    }
}
