package com.carrom.game.android.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.carrom.game.R
import com.carrom.game.core.physics.PuckType
import com.carrom.game.core.physics.RigidBody

class CarromSoundEngine(context: Context) {
    private val soundPool: SoundPool
    private val sounds = mutableMapOf<SoundType, Int>()
    
    enum class SoundType {
        STRIKER_HIT_PUCK,
        STRIKER_HIT_WALL,
        PUCK_HIT_PUCK,
        PUCK_ENTER_POCKET,
        STRIKER_DRAG,
        TURN_CHANGE,
        FOUL_BUZZER,
        WIN_FANFARE,
        QUEEN_COVERED
    }
    
    init {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        
        soundPool = SoundPool.Builder()
            .setMaxStreams(8)
            .setAudioAttributes(audioAttributes)
            .build()
        
        // Note: These resources must exist in res/raw/ for compilation
        // sounds[SoundType.STRIKER_HIT_PUCK] = soundPool.load(context, R.raw.hit_puck, 1)
        // sounds[SoundType.PUCK_ENTER_POCKET] = soundPool.load(context, R.raw.pocket, 1)
    }
    
    fun play(soundType: SoundType, volume: Float = 1.0f, rate: Float = 1.0f) {
        sounds[soundType]?.let { soundId ->
            soundPool.play(soundId, volume, volume, 1, 0, rate)
        }
    }
    
    fun playCollisionSound(relativeVelocity: Float, bodyA: RigidBody, bodyB: RigidBody) {
        val volume = (relativeVelocity / 200f).coerceIn(0.1f, 1.0f)
        val rate = 0.8f + (relativeVelocity / 500f).coerceIn(0f, 0.4f)
        
        when {
            bodyA.type is PuckType.Striker || bodyB.type is PuckType.Striker -> {
                play(SoundType.STRIKER_HIT_PUCK, volume, rate)
            }
            else -> play(SoundType.PUCK_HIT_PUCK, volume * 0.7f, rate)
        }
    }
}
