package com.carrom.game.android.input

import android.view.MotionEvent
import com.carrom.game.core.game.*
import com.carrom.game.core.math.Vector2
import com.carrom.game.core.physics.*
import com.carrom.game.core.physics.TrajectoryPredictor.*
import kotlinx.coroutines.*

class TouchController(
    private val gameManager: CarromGameManager,
    private val physicsWorld: PhysicsWorld,
    private val trajectoryPredictor: TrajectoryPredictor,
    private val boardConfig: BoardConfig,
    private val physicsConfig: PhysicsConfig,
    private val rulesEngine: CarromRulesEngine,
    private val onTrajectoryUpdate: (TrajectoryResult?) -> Unit
) {
    sealed class InputState {
        object Idle : InputState()
        data class Aiming(
            val striker: RigidBody,
            val dragStart: Vector2,
            val currentPos: Vector2
        ) : InputState()
        object Animating : InputState()
    }
    
    private var currentState: InputState = InputState.Idle
    private val touchSlop = 0.5f // world units
    private val maxDragDistance = 15f // world units
    
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    
    fun onTouchEvent(event: MotionEvent, screenToWorld: (Float, Float) -> Vector2): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val worldPos = screenToWorld(event.x, event.y)
                val striker = findStrikerAt(worldPos)
                
                if (striker != null && isPlayerTurn()) {
                    currentState = InputState.Aiming(striker, worldPos, worldPos)
                    return true
                }
            }
            
            MotionEvent.ACTION_MOVE -> {
                val state = currentState
                if (state is InputState.Aiming) {
                    val worldPos = screenToWorld(event.x, event.y)
                    val dragVector = state.dragStart - worldPos
                    val dragDistance = dragVector.length
                    
                    val clampedDrag = if (dragDistance > maxDragDistance) {
                        dragVector.normalized() * maxDragDistance
                    } else dragVector
                    
                    val aimDir = clampedDrag.normalized()
                    val power = clampedDrag.length / maxDragDistance
                    
                    val impulse = aimDir * (power * physicsConfig.maxStrikerSpeed)
                    val trajectory = trajectoryPredictor.predictStrikerPath(
                        state.striker.position,
                        impulse,
                        gameManager.state.bodies
                    )
                    
                    onTrajectoryUpdate(trajectory)
                    currentState = state.copy(currentPos = worldPos)
                    return true
                }
            }
            
            MotionEvent.ACTION_UP -> {
                val state = currentState
                if (state is InputState.Aiming) {
                    val worldPos = screenToWorld(event.x, event.y)
                    val dragVector = state.dragStart - worldPos
                    val dragDistance = dragVector.length
                    
                    if (dragDistance > touchSlop) {
                        val clampedDrag = if (dragDistance > maxDragDistance) {
                            dragVector.normalized() * maxDragDistance
                        } else dragVector
                        
                        val aimDir = clampedDrag.normalized()
                        val power = (clampedDrag.length / maxDragDistance).coerceIn(0f, 1f)
                        
                        executeShot(state.striker, aimDir, power)
                    } else {
                        onTrajectoryUpdate(null)
                    }
                    
                    currentState = InputState.Idle
                    return true
                }
            }
        }
        return false
    }
    
    private fun findStrikerAt(pos: Vector2): RigidBody? {
        return gameManager.state.bodies.find { 
            it.type is PuckType.Striker && (it.position - pos).length < it.radius * 2f 
        }
    }

    private fun isPlayerTurn(): Boolean = true // Simplified

    private fun executeShot(striker: RigidBody, direction: Vector2, power: Float) {
        val speed = power * physicsConfig.maxStrikerSpeed
        
        if (!isValidStrikerPosition(striker.position)) {
            animateStrikerToBaseline(striker)
            return
        }
        
        striker.velocity = direction * speed
        striker.isSleeping = false
        onTrajectoryUpdate(null)
        
        scope.launch {
            waitForPhysicsToSettle()
            resolveTurn()
        }
    }
    
    private suspend fun waitForPhysicsToSettle() {
        while (gameManager.state.bodies.any { !it.isSleeping && !it.isPocketed && it.velocity.length > 0.5f }) {
            delay(16)
        }
        delay(300)
    }
    
    private fun resolveTurn() {
        // Simplified: needs actual ShotContext from physics
        val shotContext = ShotContext(didHitPuck = true, wasOnBaseline = true, isBreakShot = false)
        val result = rulesEngine.validateTurn(gameManager.state, shotContext)
        gameManager.applyTurnResult(result)
        currentState = InputState.Idle
    }
    
    private fun isValidStrikerPosition(pos: Vector2): Boolean {
        val baselineY = if (gameManager.state.currentPlayer == 0) -boardConfig.baselineY else boardConfig.baselineY
        val yDiff = kotlin.math.abs(pos.y - baselineY)
        val xInRange = kotlin.math.abs(pos.x) <= boardConfig.baselineLength / 2
        return yDiff < 2f && xInRange
    }
    
    private fun animateStrikerToBaseline(striker: RigidBody) {
        scope.launch {
            val targetY = if (gameManager.state.currentPlayer == 0) -boardConfig.baselineY else boardConfig.baselineY
            val startPos = striker.position
            val targetPos = Vector2(startPos.x.coerceIn(-boardConfig.baselineLength/2, boardConfig.baselineLength/2), targetY)
            
            val duration = 300L
            val startTime = System.currentTimeMillis()
            
            while (true) {
                val elapsed = System.currentTimeMillis() - startTime
                val t = (elapsed / duration.toFloat()).coerceIn(0f, 1f)
                val eased = t * t * (3f - 2f * t)
                striker.position = startPos.lerp(targetPos, eased)
                if (t >= 1f) break
                delay(16)
            }
        }
    }
}
