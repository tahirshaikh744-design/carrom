package com.carrom.game.android.gl

import android.content.Context
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.carrom.game.R
import com.carrom.game.core.game.GameState
import com.carrom.game.core.physics.PuckType
import com.carrom.game.core.physics.TrajectoryPredictor.*
import com.carrom.game.core.rendering.Renderer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class CarromRenderer(private val context: Context) : GLSurfaceView.Renderer, Renderer {
    private val mvpMatrix = FloatArray(16)
    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    
    private lateinit var aimLineShader: ShaderProgram
    private lateinit var puckShader: ShaderProgram
    private lateinit var boardShader: ShaderProgram
    
    // VBOs
    private var aimLineVbo: Int = 0
    private var puckVbo: Int = 0
    
    @Volatile
    private var gameState: GameState? = null
    @Volatile
    private var trajectoryResult: TrajectoryResult? = null
    
    override fun render(interpolation: Float) {
        // In GLSurfaceView, we don't usually call render directly from outside.
        // Instead, we update the state and request a render, or let it run continuously.
        // For now, we'll just use this to trigger a requestRender if we were in RENDERMODE_WHEN_DIRTY
    }
    
    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.05f, 0.05f, 0.08f, 1.0f)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        
        aimLineShader = ShaderCompiler.compile(context, R.raw.vertex_aim_line, R.raw.fragment_aim_line)
        puckShader = ShaderCompiler.compile(context, R.raw.vertex_puck, R.raw.fragment_puck)
        boardShader = ShaderCompiler.compile(context, R.raw.vertex_board, R.raw.fragment_board)
        
        // Setup VBOs
        val buffers = IntArray(2)
        GLES30.glGenBuffers(2, buffers, 0)
        aimLineVbo = buffers[0]
        puckVbo = buffers[1]
        
        generatePuckGeometry()
    }
    
    private fun generatePuckGeometry() {
        val segments = 32
        val vertices = FloatArray((segments + 2) * 2)
        vertices[0] = 0f
        vertices[1] = 0f
        for (i in 0..segments) {
            val angle = (i.toFloat() / segments) * Math.PI.toFloat() * 2f
            vertices[(i + 1) * 2] = Math.cos(angle.toDouble()).toFloat()
            vertices[(i + 1) * 2 + 1] = Math.sin(angle.toDouble()).toFloat()
        }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, puckVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vertices.size * 4, vertices.toBuffer(), GLES30.GL_STATIC_DRAW)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES30.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / height.toFloat()
        val boardSize = 45f // Slightly larger than playing surface
        if (width > height) {
            Matrix.orthoM(projectionMatrix, 0, -boardSize * ratio, boardSize * ratio, -boardSize, boardSize, -1f, 1f)
        } else {
            Matrix.orthoM(projectionMatrix, 0, -boardSize, boardSize, -boardSize / ratio, boardSize / ratio, -1f, 1f)
        }
    }
    
    override fun onDrawFrame(gl: GL10?) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        val state = gameState ?: return
        
        // Use identity for view matrix in 2D to avoid Z-clipping confusion
        Matrix.setIdentityM(viewMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, viewMatrix, 0)
        
        renderBoard()
        renderPucks(state)
        renderAimLine(state)
    }

    private fun renderBoard() {
        boardShader.use()
        GLES30.glUniformMatrix4fv(boardShader.getUniformLocation("u_mvpMatrix"), 1, false, mvpMatrix, 0)
        
        // Simple quad for the board
        val size = 35f
        val vertices = floatArrayOf(
            -size, -size,
             size, -size,
            -size,  size,
             size,  size
        )
        
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0) // Unbind any VBO
        val buffer = vertices.toBuffer()
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, buffer)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }
    
    private fun renderAimLine(state: GameState) {
        val trajectory = trajectoryResult ?: return
        if (trajectory.points.size < 2) return
        
        aimLineShader.use()
        val vertices = FloatArray(trajectory.points.size * 4)
        var cumulativeDist = 0f
        trajectory.points.forEachIndexed { index, point ->
            val i = index * 4
            vertices[i] = point.position.x
            vertices[i + 1] = point.position.y
            vertices[i + 2] = point.bounceCount.toFloat()
            if (index > 0) cumulativeDist += (point.position - trajectory.points[index - 1].position).length
            vertices[i + 3] = cumulativeDist
        }
        
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, aimLineVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vertices.size * 4, vertices.toBuffer(), GLES30.GL_STREAM_DRAW)
        
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 16, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 1, GLES30.GL_FLOAT, false, 16, 8)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 1, GLES30.GL_FLOAT, false, 16, 12)
        
        GLES30.glUniformMatrix4fv(aimLineShader.getUniformLocation("u_mvpMatrix"), 1, false, mvpMatrix, 0)
        GLES30.glUniform1f(aimLineShader.getUniformLocation("u_time"), System.nanoTime() / 1_000_000_000f)
        GLES30.glUniform4f(aimLineShader.getUniformLocation("u_baseColor"), 0f, 1f, 0.5f, 0.9f)
        GLES30.glUniform1f(aimLineShader.getUniformLocation("u_dashSize"), 2.0f)
        GLES30.glUniform1f(aimLineShader.getUniformLocation("u_gapSize"), 1.0f)
        
        GLES30.glDrawArrays(GLES30.GL_LINE_STRIP, 0, trajectory.points.size)
    }
    
    private fun renderPucks(state: GameState) {
        puckShader.use()
        state.bodies.filter { !it.isPocketed }.forEach { body ->
            val modelMatrix = FloatArray(16)
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, body.position.x, body.position.y, 0f)
            
            val mvp = FloatArray(16)
            Matrix.multiplyMM(mvp, 0, mvpMatrix, 0, modelMatrix, 0)
            
            GLES30.glUniformMatrix4fv(puckShader.getUniformLocation("u_mvpMatrix"), 1, false, mvp, 0)
            
            val color = when (body.type) {
                is PuckType.White -> floatArrayOf(0.95f, 0.95f, 0.95f, 1f)
                is PuckType.Black -> floatArrayOf(0.1f, 0.1f, 0.1f, 1f)
                is PuckType.Queen -> floatArrayOf(0.9f, 0.1f, 0.1f, 1f)
                is PuckType.Striker -> floatArrayOf(0.8f, 0.8f, 0.9f, 0.6f)
            }
            GLES30.glUniform4fv(puckShader.getUniformLocation("u_color"), 1, color, 0)
            GLES30.glUniform1f(puckShader.getUniformLocation("u_radius"), body.radius)
            
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, puckVbo)
            GLES30.glEnableVertexAttribArray(0)
            GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 8, 0)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_FAN, 0, 34)
        }
    }
    
    fun updateGameState(state: GameState, trajectory: TrajectoryResult?) {
        this.gameState = state
        this.trajectoryResult = trajectory
    }
}
