package com.carrom.game.android.gl

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

fun FloatArray.toBuffer(): FloatBuffer {
    return ByteBuffer.allocateDirect(size * 4).run {
        order(ByteOrder.nativeOrder())
        asFloatBuffer().apply {
            put(this@toBuffer)
            position(0)
        }
    }
}
