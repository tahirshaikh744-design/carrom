package com.carrom.game.android

import android.opengl.GLSurfaceView
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import androidx.appcompat.app.AppCompatActivity
import com.carrom.game.android.gl.CarromRenderer
import com.carrom.game.android.input.TouchController
import com.carrom.game.core.game.*
import com.carrom.game.core.math.Vector2
import com.carrom.game.core.physics.PhysicsConfig
import com.carrom.game.core.physics.PhysicsWorld
import com.carrom.game.core.physics.TrajectoryPredictor
import com.carrom.game.core.physics.TrajectoryPredictor.TrajectoryResult

class CarromActivity : AppCompatActivity() {
    private lateinit var glSurfaceView: GLSurfaceView
    private lateinit var renderer: CarromRenderer
    private lateinit var gameLoop: GameLoop
    private lateinit var gameManager: CarromGameManager
    private lateinit var physicsWorld: PhysicsWorld
    private lateinit var touchController: TouchController
    
    private val boardConfig = BoardConfig.STANDARD
    private val physicsConfig = PhysicsConfig()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("CarromActivity", "onCreate called")

        // 1. Initialize Core Components
        gameManager = CarromGameManager(boardConfig)
        physicsWorld = PhysicsWorld(boardConfig)
        
        // Add bodies to physics world
        gameManager.state.bodies.forEach { physicsWorld.addBody(it) }

        val trajectoryPredictor = TrajectoryPredictor(boardConfig, physicsConfig)
        val rulesEngine = CarromRulesEngine(boardConfig)

        // 2. Setup Renderer
        renderer = CarromRenderer(this)
        renderer.updateGameState(gameManager.state, null)

        // 3. Setup Touch Controller
        touchController = TouchController(
            gameManager = gameManager,
            physicsWorld = physicsWorld,
            trajectoryPredictor = trajectoryPredictor,
            boardConfig = boardConfig,
            physicsConfig = physicsConfig,
            rulesEngine = rulesEngine,
            onTrajectoryUpdate = { trajectory ->
                renderer.updateGameState(gameManager.state, trajectory)
            }
        )

        // 4. Setup GLSurfaceView
        glSurfaceView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3)
            setRenderer(renderer)
            // RENDERMODE_CONTINUOUSLY is default, which is what we want for GameLoop
        }
        setContentView(glSurfaceView)

        // 5. Setup and Start GameLoop
        gameLoop = GameLoop(renderer, physicsWorld, gameManager)
        gameLoop.start()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        Log.d("CarromActivity", "onTouchEvent: ${event.action} at ${event.x}, ${event.y}")
        val handled = touchController.onTouchEvent(event) { x, y ->
            // Simple Screen to World conversion
            // This needs to be calibrated based on the projection matrix in CarromRenderer
            val worldX = (x / glSurfaceView.width - 0.5f) * 90f // boardSize is 45f in renderer (half-width)
            val worldY = -(y / glSurfaceView.height - 0.5f) * 90f * (glSurfaceView.height.toFloat() / glSurfaceView.width)
            Vector2(worldX, worldY)
        }
        Log.d("CarromActivity", "touchController handled: $handled")
        return handled || super.onTouchEvent(event)
    }

    override fun onResume() {
        super.onResume()
        glSurfaceView.onResume()
    }

    override fun onPause() {
        super.onPause()
        glSurfaceView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        gameLoop.stop()
    }
}
