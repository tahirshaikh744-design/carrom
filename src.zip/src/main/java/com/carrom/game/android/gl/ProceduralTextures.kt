package com.carrom.game.android.gl

import android.graphics.*
import android.opengl.GLES30
import android.opengl.GLUtils

class ProceduralTextures {
    
    fun generateBoardTexture(width: Int = 1024, height: Int = 1024): Int {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        
        // Wood base color
        canvas.drawColor(Color.rgb(139, 90, 43)) // Saddle brown
        
        // Wood grain using Perlin noise simulation
        val paint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.FILL
        }
        
        // Generate grain lines
        val random = java.util.Random(12345) // Seeded for consistency
        for (i in 0..200) {
            val y = random.nextFloat() * height
            val strokeWidth = 1f + random.nextFloat() * 3f
            val alpha = 20 + random.nextInt(40)
            
            paint.color = Color.argb(alpha, 80, 50, 20)
            paint.strokeWidth = strokeWidth
            
            val path = Path()
            path.moveTo(0f, y)
            var currentY = y
            for (x in 0..width step 20) {
                currentY += (random.nextFloat() - 0.5f) * 10f
                path.lineTo(x.toFloat(), currentY)
            }
            canvas.drawPath(path, paint)
        }
        
        // Border (darker wood)
        val borderPaint = Paint().apply {
            color = Color.rgb(101, 67, 33)
            style = Paint.Style.STROKE
            strokeWidth = (width * 0.07f)
        }
        canvas.drawRect(
            borderPaint.strokeWidth / 2,
            borderPaint.strokeWidth / 2,
            width - borderPaint.strokeWidth / 2,
            height - borderPaint.strokeWidth / 2,
            borderPaint
        )
        
        // Center circle
        val centerPaint = Paint().apply {
            color = Color.argb(100, 255, 255, 255)
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawCircle(width / 2f, height / 2f, width * 0.1f, centerPaint)
        
        // Baselines
        val baselinePaint = Paint().apply {
            color = Color.argb(150, 255, 255, 255)
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        val baselineY = height * 0.35f
        canvas.drawLine(width * 0.15f, baselineY, width * 0.85f, baselineY, baselinePaint)
        canvas.drawLine(width * 0.15f, height - baselineY, width * 0.85f, height - baselineY, baselinePaint)
        
        return loadTexture(bitmap)
    }
    
    private fun loadTexture(bitmap: Bitmap): Int {
        val textures = IntArray(1)
        GLES30.glGenTextures(1, textures, 0)
        val textureId = textures[0]
        
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bitmap, 0)
        
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        
        bitmap.recycle()
        return textureId
    }
}
