package com.carrom.game.core.math

data class Rect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    
    fun contains(x: Float, y: Float): Boolean {
        return x in left..right && y in top..bottom
    }
}
