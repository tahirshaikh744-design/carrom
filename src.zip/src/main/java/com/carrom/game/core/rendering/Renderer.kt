package com.carrom.game.core.rendering

interface Renderer {
    fun render(interpolation: Float)
}
