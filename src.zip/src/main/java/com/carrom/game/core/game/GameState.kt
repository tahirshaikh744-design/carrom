package com.carrom.game.core.game

import com.carrom.game.core.physics.RigidBody

data class PlayerStats(
    var pucksPocketed: Int = 0,
    var fouls: Int = 0,
    var score: Int = 0
)

data class ShotContext(
    val didHitPuck: Boolean,
    val wasOnBaseline: Boolean,
    val isBreakShot: Boolean
)

data class GameState(
    val bodies: List<RigidBody>,
    val currentPlayer: Int = 0,
    val isGameOver: Boolean = false,
    val playerStats: List<PlayerStats> = listOf(PlayerStats(), PlayerStats()),
    val queenCoverPending: Boolean = false,
    val winner: Int? = null
)
