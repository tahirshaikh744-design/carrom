package com.carrom.game.core.game

import com.carrom.game.core.math.Vector2
import com.carrom.game.core.math.Rect

data class Pocket(val position: Vector2, val radius: Float, val index: Int)

data class Wall(val start: Vector2, val end: Vector2) {
    val normal: Vector2 by lazy {
        val dir = end - start
        Vector2(-dir.y, dir.x).normalized()
    }
}

data class BoardConfig(
    val boardSize: Float = 74f,           // cm (full board)
    val playingSurface: Float = 66f,       // cm (inner area)
    val borderWidth: Float = 5.1f,         // cm
    val pocketRadius: Float = 2.25f,        // cm (slightly larger than puck)
    val baselineY: Float = 25f,            // cm from center
    val baselineLength: Float = 47f,       // cm
    val centerCircleRadius: Float = 7f,    // cm
    val strikerRadius: Float = 2.065f,     // cm (4.13cm diameter)
    val puckRadius: Float = 1.59f,         // cm (3.18cm diameter)
    val queenRadius: Float = 1.59f,        // Same as puck
    val wallRestitution: Float = 0.7f,
    val strikerMass: Float = 15f,          // grams
    val puckMass: Float = 5.5f,            // grams
    val queenMass: Float = 5.5f,
    val frictionCoefficient: Float = 0.15f
) {
    val pockets: List<Pocket> = listOf(
        Pocket(Vector2(-playingSurface/2, -playingSurface/2), pocketRadius * 1.2f, 0),
        Pocket(Vector2(playingSurface/2, -playingSurface/2), pocketRadius * 1.2f, 1),
        Pocket(Vector2(-playingSurface/2, playingSurface/2), pocketRadius * 1.2f, 2),
        Pocket(Vector2(playingSurface/2, playingSurface/2), pocketRadius * 1.2f, 3)
    )
    
    val walls: List<Wall> = listOf(
        Wall(Vector2(-playingSurface/2, -playingSurface/2), Vector2(playingSurface/2, -playingSurface/2)),
        Wall(Vector2(playingSurface/2, -playingSurface/2), Vector2(playingSurface/2, playingSurface/2)),
        Wall(Vector2(playingSurface/2, playingSurface/2), Vector2(-playingSurface/2, playingSurface/2)),
        Wall(Vector2(-playingSurface/2, playingSurface/2), Vector2(-playingSurface/2, -playingSurface/2))
    )

    val bounds: Rect = Rect(
        -playingSurface/2, -playingSurface/2,
        playingSurface/2, playingSurface/2
    )
    
    companion object {
        val STANDARD = BoardConfig()
    }
}
