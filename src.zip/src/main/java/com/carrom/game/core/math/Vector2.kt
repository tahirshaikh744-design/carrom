package com.carrom.game.core.math

data class Vector2(val x: Float, val y: Float) {
    operator fun plus(other: Vector2) = Vector2(x + other.x, y + other.y)
    operator fun minus(other: Vector2) = Vector2(x - other.x, y - other.y)
    operator fun times(scalar: Float) = Vector2(x * scalar, y * scalar)
    operator fun div(scalar: Float) = Vector2(x / scalar, y / scalar)
    operator fun unaryMinus() = Vector2(-x, -y)
    
    val length: Float get() = kotlin.math.hypot(x, y)
    val lengthSquared: Float get() = x * x + y * y
    
    fun normalized(): Vector2 {
        val len = length
        return if (len > 0.0001f) Vector2(x / len, y / len) else Vector2(0f, 0f)
    }
    
    fun dot(other: Vector2): Float = x * other.x + y * other.y
    fun cross(other: Vector2): Float = x * other.y - y * other.x
    fun reflect(normal: Vector2): Vector2 {
        val dot2 = 2f * this.dot(normal)
        return Vector2(x - dot2 * normal.x, y - dot2 * normal.y)
    }
    fun perpendicular(): Vector2 = Vector2(-y, x)
    fun lerp(target: Vector2, t: Float): Vector2 = this * (1f - t) + target * t
    
    companion object {
        val ZERO = Vector2(0f, 0f)
        val ONE = Vector2(1f, 1f)
        val UP = Vector2(0f, 1f)
        val RIGHT = Vector2(1f, 0f)
    }
}
