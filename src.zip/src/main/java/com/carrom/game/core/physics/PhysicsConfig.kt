package com.carrom.game.core.physics

data class PhysicsConfig(
    val friction: Float = 0.018f,
    val physicsStep: Float = 1f / 120f,
    val sleepThreshold: Float = 0.3f,
    val bounceThreshold: Float = 0.5f,
    val maxStrikerSpeed: Float = 300f
)
