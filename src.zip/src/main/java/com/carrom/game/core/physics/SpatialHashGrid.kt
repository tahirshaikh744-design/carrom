package com.carrom.game.core.physics

import com.carrom.game.core.math.Rect
import com.carrom.game.core.math.Vector2

class SpatialHashGrid(
    private val cellSize: Float = 8f,  // Slightly larger than puck diameter
    private val bounds: Rect = Rect(-50f, -50f, 50f, 50f)
) {
    private val cells = mutableMapOf<Long, MutableList<RigidBody>>()
    
    private fun getCellKey(x: Int, y: Int): Long = (x.toLong() shl 32) or (y.toLong() and 0xFFFFFFFFL)
    
    fun insert(body: RigidBody) {
        val minX = ((body.position.x - body.radius - bounds.left) / cellSize).toInt()
        val maxX = ((body.position.x + body.radius - bounds.left) / cellSize).toInt()
        val minY = ((body.position.y - body.radius - bounds.top) / cellSize).toInt()
        val maxY = ((body.position.y + body.radius - bounds.top) / cellSize).toInt()
        
        for (x in minX..maxX) {
            for (y in minY..maxY) {
                cells.getOrPut(getCellKey(x, y)) { mutableListOf() }.add(body)
            }
        }
    }
    
    fun queryPotentialCollisions(body: RigidBody): List<RigidBody> {
        val result = mutableSetOf<RigidBody>()
        val minX = ((body.position.x - body.radius - bounds.left) / cellSize).toInt()
        val maxX = ((body.position.x + body.radius - bounds.left) / cellSize).toInt()
        val minY = ((body.position.y - body.radius - bounds.top) / cellSize).toInt()
        val maxY = ((body.position.y + body.radius - bounds.top) / cellSize).toInt()
        
        for (x in minX..maxX) {
            for (y in minY..maxY) {
                cells[getCellKey(x, y)]?.let { result.addAll(it) }
            }
        }
        result.remove(body)
        return result.toList()
    }
    
    fun clear() = cells.clear()
}
