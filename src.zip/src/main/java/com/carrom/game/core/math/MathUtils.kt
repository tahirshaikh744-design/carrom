package com.carrom.game.core.math

import kotlin.math.max
import kotlin.math.min

object MathUtils {
    fun clamp(value: Float, min: Float, max: Float): Float = max(min, min(max, value))
    
    fun lerp(start: Float, end: Float, t: Float): Float = start + (end - start) * t
    
    fun reflect(velocity: Vector2, normal: Vector2): Vector2 {
        return velocity.reflect(normal)
    }
}
