package com.carrom.game.core.physics

import com.carrom.game.core.math.Vector2

object PerformanceConfig {
    // Rendering
    const val MAX_BATCH_SIZE = 1000
    const val POOL_VERTEX_BUFFER_SIZE = 1024 * 1024 // 1MB
    const val USE_INSTANCING = true // For identical pucks
    
    // Physics
    const val PHYSICS_SUBSTEPS = 8
    const val SLEEP_THRESHOLD_VELOCITY = 0.5f
    const val SLEEP_THRESHOLD_ANGULAR = 0.1f
    const val MAX_BODIES = 20 // Carrom has 19 + striker
    
    // Memory
    const val OBJECT_POOL_SIZE = 50
    const val TRAJECTORY_MAX_POINTS = 500
}

class ObjectPools {
    private val vectorPool = ArrayDeque<Vector2>()
    
    fun obtainVector(x: Float = 0f, y: Float = 0f): Vector2 {
        return if (vectorPool.isEmpty()) {
            Vector2(x, y)
        } else {
            val v = vectorPool.removeFirst()
            // Value classes are immutable, so we can't 'reset' them
            // but we can return a new one if needed. 
            // In this specific case, obtainVector returns a Vector2.
            Vector2(x, y)
        }
    }
    
    fun recycleVector(v: Vector2) {
        if (vectorPool.size < PerformanceConfig.OBJECT_POOL_SIZE) {
            vectorPool.addLast(v)
        }
    }
}
