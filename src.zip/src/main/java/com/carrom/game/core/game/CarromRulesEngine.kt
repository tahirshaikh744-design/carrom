package com.carrom.game.core.game

import com.carrom.game.core.physics.RigidBody
import com.carrom.game.core.physics.PuckType

class CarromRulesEngine(private val config: BoardConfig) {
    
    data class TurnResult(
        val isValid: Boolean,
        val pocketedPucks: List<RigidBody>,
        val fouls: List<Foul>,
        val turnContinues: Boolean,
        val queenCovered: Boolean = false,
        val returnToCenter: List<RigidBody> = emptyList(),
        val scoreChange: Pair<Int, Int> = 0 to 0 // (player1, player2)
    )
    
    sealed class Foul {
        object StrikerPocketed : Foul()
        object OpponentPuckPocketed : Foul()
        object QueenWithoutCover : Foul()
        object QueenBeforeOwnPuck : Foul()
        object StrikerOffBaseline : Foul()
        object NoPuckHit : Foul()
        data class InvalidQueenCover(val attemptedCover: RigidBody) : Foul()
    }
    
    fun validateTurn(state: GameState, shot: ShotContext): TurnResult {
        val pocketed = state.bodies.filter { it.isPocketed && it.type !is PuckType.Striker }
        val strikerPocketed = state.bodies.any { it.type is PuckType.Striker && it.isPocketed }
        val queenPocketed = pocketed.any { it.type is PuckType.Queen }
        val currentPlayer = state.currentPlayer
        val playerColor = if (currentPlayer == 0) PuckType.White else PuckType.Black
        
        val fouls = mutableListOf<Foul>()
        val returnToCenter = mutableListOf<RigidBody>()
        
        // Foul 1: Striker pocketed
        if (strikerPocketed) {
            fouls.add(Foul.StrikerPocketed)
            // Return pocketed opponent pucks to center
            val opponentPocketed = pocketed.filter { 
                it.type != playerColor && it.type !is PuckType.Queen 
            }
            returnToCenter.addAll(opponentPocketed)
        }
        
        // Foul 2: Opponent puck pocketed
        val opponentPocketed = pocketed.filter { 
            it.type != playerColor && it.type !is PuckType.Queen && !strikerPocketed
        }
        if (opponentPocketed.isNotEmpty()) {
            fouls.add(Foul.OpponentPuckPocketed)
            returnToCenter.addAll(opponentPocketed)
        }
        
        // Foul 3: Queen pocketed without having pocketed own puck before
        if (queenPocketed) {
            val ownPocketedBefore = state.playerStats[currentPlayer].pucksPocketed > 0
            if (!ownPocketedBefore) {
                fouls.add(Foul.QueenBeforeOwnPuck)
                returnToCenter.addAll(pocketed.filter { it.type is PuckType.Queen })
            }
        }
        
        // Foul 4: No puck hit
        if (!shot.didHitPuck) {
            fouls.add(Foul.NoPuckHit)
        }
        
        // Foul 5: Striker off baseline
        if (!shot.wasOnBaseline && !shot.isBreakShot) {
            fouls.add(Foul.StrikerOffBaseline)
        }
        
        // Calculate turn continuation
        val ownPocketed = pocketed.filter { it.type == playerColor }
        val turnContinues = when {
            fouls.isNotEmpty() -> false
            queenPocketed && ownPocketed.isEmpty() -> false
            ownPocketed.isNotEmpty() -> true
            else -> false
        }
        
        var queenCovered = false
        if (state.queenCoverPending && ownPocketed.isNotEmpty()) {
            queenCovered = true
        }
        
        return TurnResult(
            isValid = fouls.isEmpty(),
            pocketedPucks = pocketed,
            fouls = fouls,
            turnContinues = turnContinues,
            queenCovered = queenCovered,
            returnToCenter = returnToCenter,
            scoreChange = calculateScore(pocketed, fouls, queenCovered, currentPlayer)
        )
    }
    
    private fun calculateScore(
        pocketed: List<RigidBody>,
        fouls: List<Foul>,
        queenCovered: Boolean,
        player: Int
    ): Pair<Int, Int> {
        if (fouls.isNotEmpty()) return 0 to 0
        
        val basePoints = pocketed.count { it.type != PuckType.Queen }
        val queenBonus = if (queenCovered) 5 else 0
        
        return if (player == 0) {
            (basePoints + queenBonus) to 0
        } else {
            0 to (basePoints + queenBonus)
        }
    }
    
    fun checkWinCondition(state: GameState): Int? {
        val p1Pucks = state.bodies.count { it.type is PuckType.White && it.isPocketed }
        val p2Pucks = state.bodies.count { it.type is PuckType.Black && it.isPocketed }
        val queenPocketed = state.bodies.any { it.type is PuckType.Queen && it.isPocketed }
        val queenCovered = !state.queenCoverPending && queenPocketed
        
        if (p1Pucks == 9 && queenCovered) return 0
        if (p2Pucks == 9 && queenCovered) return 1
        
        return null
    }
}
