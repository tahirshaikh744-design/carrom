package com.carrom.game.core.game

import com.carrom.game.core.math.Vector2
import com.carrom.game.core.physics.PuckType
import com.carrom.game.core.physics.RigidBody
import kotlin.math.cos
import kotlin.math.sin

class CarromGameManager(
    private val config: BoardConfig = BoardConfig.STANDARD
) : GameStateManager {
    
    var state: GameState = createInitialState()
        private set

    override fun update(dt: Float) {
        // Handle game logic updates (turn switching, etc.)
    }

    fun applyTurnResult(result: CarromRulesEngine.TurnResult) {
        // Update score, handle fouls, switch players
        val currentStats = state.playerStats[state.currentPlayer]
        
        // Simplified scoring
        currentStats.pucksPocketed += result.pocketedPucks.size
        
        var nextPlayer = state.currentPlayer
        if (!result.turnContinues) {
            nextPlayer = (state.currentPlayer + 1) % 2
        }

        state = state.copy(
            currentPlayer = nextPlayer,
            playerStats = state.playerStats // In a real app, copy and update
        )
    }

    private fun createInitialState(): GameState {
        val bodies = mutableListOf<RigidBody>()
        
        // 1. Queen at center
        bodies.add(RigidBody(
            position = Vector2.ZERO,
            radius = config.queenRadius,
            mass = config.queenMass,
            type = PuckType.Queen
        ))
        
        // 2. Inner circle (6 white, 6 black alternating)
        val innerRadius = config.puckRadius * 2.1f
        for (i in 0 until 6) {
            val angle = (i * 60f) * (Math.PI / 180f).toFloat()
            val type = if (i % 2 == 0) PuckType.White else PuckType.Black
            bodies.add(RigidBody(
                position = Vector2(cos(angle) * innerRadius, sin(angle) * innerRadius),
                radius = config.puckRadius,
                mass = config.puckMass,
                type = type
            ))
        }
        
        // 3. Outer circle (12 pucks)
        val outerRadius = config.puckRadius * 4.1f
        for (i in 0 until 12) {
            val angle = (i * 30f + 15f) * (Math.PI / 180f).toFloat()
            val type = if (i % 2 == 0) PuckType.Black else PuckType.White
            bodies.add(RigidBody(
                position = Vector2(cos(angle) * outerRadius, sin(angle) * outerRadius),
                radius = config.puckRadius,
                mass = config.puckMass,
                type = type
            ))
        }
        
        // 4. Striker at baseline
        bodies.add(RigidBody(
            position = Vector2(0f, -config.baselineY),
            radius = config.strikerRadius,
            mass = config.strikerMass,
            type = PuckType.Striker
        ))
        
        return GameState(bodies = bodies)
    }
}
