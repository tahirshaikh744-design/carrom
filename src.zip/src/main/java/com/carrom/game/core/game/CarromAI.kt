package com.carrom.game.core.game

import com.carrom.game.core.math.Vector2
import com.carrom.game.core.physics.PuckType
import com.carrom.game.core.physics.RigidBody
import com.carrom.game.core.physics.TrajectoryPredictor
import com.carrom.game.core.physics.TrajectoryPredictor.*
import kotlin.math.cos
import kotlin.math.sin

data class ShotCandidate(
    val strikerPosition: Vector2,
    val direction: Vector2,
    val power: Float,
    val isQueenShot: Boolean = false,
    val queenCoverPocket: Int? = null
)

class CarromAI(
    private val trajectoryPredictor: TrajectoryPredictor,
    private val boardConfig: BoardConfig,
    private val difficulty: Difficulty = Difficulty.MEDIUM
) {
    enum class Difficulty {
        EASY,    // 30% shot accuracy
        MEDIUM,  // 60% accuracy
        HARD,    // 85% accuracy
        EXPERT   // 95% accuracy
    }
    
    data class ShotEvaluation(
        val shot: ShotCandidate,
        val successProbability: Float,
        val positionAfterShot: Vector2,
        val leavesGoodPosition: Boolean,
        val riskOfFoul: Float,
        val setsUpNextShot: Boolean,
        val totalScore: Float
    )
    
    fun selectShot(state: GameState, aiPlayer: Int): ShotCandidate? {
        val aiColor = if (aiPlayer == 0) PuckType.White else PuckType.Black
        val myPucks = state.bodies.filter { it.type == aiColor && !it.isPocketed }
        val queen = state.bodies.find { it.type is PuckType.Queen && !it.isPocketed }
        
        val candidates = mutableListOf<ShotEvaluation>()
        val baselinePositions = generateBaselinePositions(aiPlayer)
        
        baselinePositions.forEach { strikerPos ->
            myPucks.forEach { puck ->
                boardConfig.pockets.forEach { pocket ->
                    val directShot = trajectoryPredictor.calculateDirectShot(
                        strikerPos, puck, pocket, state.bodies
                    )
                    directShot?.let { evaluateShot(it, state, aiPlayer, candidates) }
                }
            }
            
            queen?.let { q ->
                if (state.playerStats[aiPlayer].pucksPocketed > 0 || myPucks.isEmpty()) {
                    boardConfig.pockets.forEach { pocket ->
                        val queenShot = trajectoryPredictor.calculateDirectShot(
                            strikerPos, q, pocket, state.bodies
                        )
                        queenShot?.let { shot ->
                            evaluateShot(shot, state, aiPlayer, candidates, isQueen = true)
                        }
                    }
                }
            }
        }
        
        if (candidates.isEmpty()) return null
        
        val accuracyModifier = when (difficulty) {
            Difficulty.EASY -> 0.3f
            Difficulty.MEDIUM -> 0.6f
            Difficulty.HARD -> 0.85f
            Difficulty.EXPERT -> 0.95f
        }
        
        val best = candidates.maxByOrNull { it.totalScore * accuracyModifier }
        return best?.shot?.let { addHumanVariation(it) }
    }
    
    private fun generateBaselinePositions(player: Int): List<Vector2> {
        val y = if (player == 0) -boardConfig.baselineY else boardConfig.baselineY
        val startX = -boardConfig.baselineLength / 2
        return (0..10).map { i -> 
            Vector2(startX + (i * boardConfig.baselineLength / 10f), y)
        }
    }
    
    private fun evaluateShot(
        shot: TrajectoryResult,
        state: GameState,
        aiPlayer: Int,
        candidates: MutableList<ShotEvaluation>,
        isQueen: Boolean = false
    ) {
        val strikerEndPos = shot.points.lastOrNull()?.position ?: return
        val risk = if (shot.points.any { it.isPocket && it.position == shot.points.first().position }) 1f else 0.1f
        
        var score = 0f
        if (shot.pocketedPuckId != null) score += 100f
        if (isQueen) score += 50f
        score -= risk * 50f
        
        candidates.add(ShotEvaluation(
            shot = ShotCandidate(
                strikerPosition = shot.points.first().position,
                direction = shot.requiredImpulse?.normalized() ?: Vector2.ZERO,
                power = (shot.requiredImpulse?.length ?: 0f) / 300f, // MAX_STRIKER_SPEED
                isQueenShot = isQueen
            ),
            successProbability = if (shot.pocketedPuckId != null) 0.8f else 0.2f,
            positionAfterShot = strikerEndPos,
            leavesGoodPosition = true,
            riskOfFoul = risk,
            setsUpNextShot = false,
            totalScore = score
        ))
    }
    
    private fun addHumanVariation(shot: ShotCandidate): ShotCandidate {
        val angleVar = (Math.random() - 0.5).toFloat() * 0.02f
        val powerVar = (Math.random() - 0.5).toFloat() * 0.05f
        
        val cosA = cos(angleVar.toDouble()).toFloat()
        val sinA = sin(angleVar.toDouble()).toFloat()
        val variedDir = Vector2(
            shot.direction.x * cosA - shot.direction.y * sinA,
            shot.direction.x * sinA + shot.direction.y * cosA
        )
        
        return shot.copy(
            direction = variedDir,
            power = (shot.power + powerVar).coerceIn(0.1f, 1.0f)
        )
    }
}
