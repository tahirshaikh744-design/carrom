package com.carrom.game.core.physics

import com.carrom.game.core.game.BoardConfig
import com.carrom.game.core.game.Pocket
import com.carrom.game.core.game.Wall
import com.carrom.game.core.math.Vector2
import com.carrom.game.core.physics.RigidBody
import kotlin.math.sqrt

class TrajectoryPredictor(
    private val boardConfig: BoardConfig,
    private val physicsConfig: PhysicsConfig
) {
    data class TrajectoryPoint(
        val position: Vector2,
        val velocity: Vector2,
        val time: Float,
        val isBounce: Boolean = false,
        val bounceNormal: Vector2? = null,
        val hitPuckId: Int? = null,
        val isPocket: Boolean = false,
        val pocketIndex: Int? = null,
        val bounceCount: Int = 0
    )
    
    data class TrajectoryResult(
        val points: List<TrajectoryPoint>,
        val finalPosition: Vector2,
        val isValidShot: Boolean,
        val pocketedPuckId: Int? = null,
        val pocketIndex: Int? = null,
        val requiredImpulse: Vector2? = null
    )

    data class RayHit(
        val point: Vector2,
        val normal: Vector2,
        val distance: Float,
        val puckId: Int? = null
    )
    
    fun predictStrikerPath(
        startPos: Vector2,
        impulse: Vector2,
        currentPucks: List<RigidBody> = emptyList(),
        maxTime: Float = 3f,
        maxBounces: Int = 5
    ): TrajectoryResult {
        val points = mutableListOf<TrajectoryPoint>()
        var pos = startPos
        var vel = impulse
        var time = 0f
        var bounces = 0
        val timeStep = physicsConfig.physicsStep
        
        points.add(TrajectoryPoint(pos, vel, time))
        
        while (time < maxTime && bounces <= maxBounces && vel.length > 0.5f) {
            val nextPos = pos + vel * timeStep
            
            // Wall collision check
            val wallHit = checkWallHit(pos, nextPos, boardConfig.strikerRadius)
            if (wallHit != null) {
                points.add(TrajectoryPoint(
                    position = wallHit.point,
                    velocity = vel,
                    time = time,
                    isBounce = true,
                    bounceNormal = wallHit.normal,
                    bounceCount = bounces
                ))
                
                // Reflect with energy loss
                vel = vel.reflect(wallHit.normal) * boardConfig.wallRestitution
                pos = wallHit.point + vel.normalized() * 0.01f
                bounces++
                continue
            }
            
            // Puck collision check
            val puckHit = checkPuckHit(pos, nextPos, boardConfig.strikerRadius, currentPucks)
            if (puckHit != null) {
                points.add(TrajectoryPoint(
                    position = puckHit.point,
                    velocity = vel,
                    time = time,
                    hitPuckId = puckHit.puckId
                ))
                break
            }
            
            // Pocket check
            val pocketHit = checkPocketEntry(nextPos, boardConfig.strikerRadius)
            if (pocketHit != null) {
                points.add(TrajectoryPoint(
                    position = nextPos,
                    velocity = vel,
                    time = time,
                    isPocket = true,
                    pocketIndex = pocketHit
                ))
                break
            }
            
            // Apply friction
            vel *= (1f - physicsConfig.friction * timeStep)
            
            pos = nextPos
            time += timeStep
            points.add(TrajectoryPoint(pos, vel, time, bounceCount = bounces))
        }
        
        return TrajectoryResult(
            points = points,
            finalPosition = pos,
            isValidShot = true
        )
    }

    private fun checkWallHit(start: Vector2, end: Vector2, radius: Float): RayHit? {
        val bounds = boardConfig.bounds
        var bestHit: RayHit? = null
        var minDist = Float.MAX_VALUE

        // Simplified wall check against board bounds
        if (end.x - radius < bounds.left) {
            val hitX = bounds.left + radius
            val hitY = start.y + (end.y - start.y) * (hitX - start.x) / (end.x - start.x)
            val d = (Vector2(hitX, hitY) - start).length
            if (d < minDist) {
                minDist = d
                bestHit = RayHit(Vector2(bounds.left, hitY), Vector2(1f, 0f), d)
            }
        }
        if (end.x + radius > bounds.right) {
            val hitX = bounds.right - radius
            val hitY = start.y + (end.y - start.y) * (hitX - start.x) / (end.x - start.x)
            val d = (Vector2(hitX, hitY) - start).length
            if (d < minDist) {
                minDist = d
                bestHit = RayHit(Vector2(bounds.right, hitY), Vector2(-1f, 0f), d)
            }
        }
        if (end.y - radius < bounds.top) {
            val hitY = bounds.top + radius
            val hitX = start.x + (end.x - start.x) * (hitY - start.y) / (end.y - start.y)
            val d = (Vector2(hitX, hitY) - start).length
            if (d < minDist) {
                minDist = d
                bestHit = RayHit(Vector2(hitX, bounds.top), Vector2(0f, 1f), d)
            }
        }
        if (end.y + radius > bounds.bottom) {
            val hitY = bounds.bottom - radius
            val hitX = start.x + (end.x - start.x) * (hitY - start.y) / (end.y - start.y)
            val d = (Vector2(hitX, hitY) - start).length
            if (d < minDist) {
                minDist = d
                bestHit = RayHit(Vector2(hitX, bounds.bottom), Vector2(0f, -1f), d)
            }
        }

        return bestHit
    }

    private fun checkPuckHit(start: Vector2, end: Vector2, radius: Float, pucks: List<RigidBody>): RayHit? {
        pucks.forEach { puck ->
            if (puck.isPocketed) return@forEach
            val dist = (end - puck.position).length
            if (dist < radius + puck.radius) {
                val normal = (end - puck.position).normalized()
                return RayHit(end, normal, (end - start).length, puck.id)
            }
        }
        return null
    }

    private fun checkPocketEntry(pos: Vector2, radius: Float): Int? {
        boardConfig.pockets.forEach { pocket ->
            if ((pos - pocket.position).length < pocket.radius * 0.85f) {
                return pocket.index
            }
        }
        return null
    }
    
    fun calculateDirectShot(
        strikerPos: Vector2,
        targetPuck: RigidBody,
        targetPocket: Pocket,
        currentPucks: List<RigidBody>
    ): TrajectoryResult? {
        val pocketToPuck = (targetPuck.position - targetPocket.position).normalized()
        val impactOffset = pocketToPuck * (targetPuck.radius + boardConfig.strikerRadius + 0.05f)
        val impactPoint = targetPuck.position + impactOffset
        
        val shotDirection = (impactPoint - strikerPos).normalized()
        val puckToPocketDist = (targetPuck.position - targetPocket.position).length
        val requiredPuckVel = sqrt(2f * physicsConfig.friction * puckToPocketDist * 120f)
        val strikerImpactSpeed = requiredPuckVel * 1.6f
        
        val predictedPath = predictStrikerPath(
            strikerPos,
            shotDirection * strikerImpactSpeed,
            currentPucks,
            maxTime = 2f,
            maxBounces = 0
        )
        
        val firstHit = predictedPath.points.find { it.hitPuckId == targetPuck.id }
        if (firstHit == null) return null
        
        return predictedPath.copy(
            pocketedPuckId = targetPuck.id,
            pocketIndex = targetPocket.index,
            requiredImpulse = shotDirection * strikerImpactSpeed
        )
    }
    
    fun calculateBankShots(
        strikerPos: Vector2,
        targetPuck: RigidBody,
        targetPocket: Pocket,
        currentPucks: List<RigidBody>
    ): List<TrajectoryResult> {
        val solutions = mutableListOf<TrajectoryResult>()
        
        boardConfig.walls.forEach { wall ->
            val mirroredPocketPos = mirrorPointAcrossLine(targetPocket.position, wall.start, wall.end)
            val mirroredPocket = Pocket(mirroredPocketPos, targetPocket.radius, targetPocket.index)
            
            calculateDirectShot(strikerPos, targetPuck, mirroredPocket, currentPucks)?.let { shot ->
                solutions.add(shot)
            }
        }
        
        return solutions.sortedBy { it.points.size }
    }
    
    private fun mirrorPointAcrossLine(point: Vector2, lineStart: Vector2, lineEnd: Vector2): Vector2 {
        val lineVec = lineEnd - lineStart
        val lineLenSq = lineVec.lengthSquared
        if (lineLenSq < 0.0001f) return point
        
        val t = ((point - lineStart).dot(lineVec) / lineLenSq).coerceIn(0f, 1f)
        val projection = lineStart + lineVec * t
        return projection * 2f - point
    }
}
