package com.carrom.game.core.physics

import com.carrom.game.core.math.Vector2

sealed class PuckType {
    object Striker : PuckType()
    object White : PuckType()
    object Black : PuckType()
    object Queen : PuckType()
}

data class RigidBody(
    var position: Vector2 = Vector2.ZERO,
    var velocity: Vector2 = Vector2.ZERO,
    var mass: Float = 1f,
    val radius: Float = 1f,
    val restitution: Float = 0.65f,  // Bounciness
    val friction: Float = 0.018f,   // Surface friction per second
    var angularVelocity: Float = 0f,
    val inertia: Float = 0.5f * mass * radius * radius,
    val type: PuckType,
    val id: Int = generateId(),
    var isPocketed: Boolean = false,
    var isSleeping: Boolean = false
) {
    companion object {
        private var nextId = 0
        fun generateId(): Int = nextId++
    }
    
    val inverseMass: Float get() = if (mass > 0f) 1f / mass else 0f
    val inverseInertia: Float get() = if (inertia > 0f) 1f / inertia else 0f
    
    fun applyImpulse(impulse: Vector2, contactVector: Vector2) {
        velocity += impulse * inverseMass
        angularVelocity += contactVector.cross(impulse) * inverseInertia
    }
    
    fun kineticEnergy(): Float = 0.5f * mass * velocity.lengthSquared
}
