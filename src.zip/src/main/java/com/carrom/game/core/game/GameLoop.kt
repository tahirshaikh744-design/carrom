package com.carrom.game.core.game

import com.carrom.game.core.physics.PhysicsWorld
import com.carrom.game.core.rendering.Renderer
import kotlinx.coroutines.*

class GameLoop(
    private val renderer: Renderer,
    private val physicsWorld: PhysicsWorld,
    private val gameState: GameStateManager
) {
    private val targetFPS = 60
    private val frameTimeNs = 1_000_000_000L / targetFPS
    private val physicsStep = 1f / 120f  // 120Hz physics for precision
    
    private var running = false
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    fun start() {
        running = true
        scope.launch {
            var accumulator = 0f
            var lastTime = System.nanoTime()
            
            while (running) {
                val currentTime = System.nanoTime()
                val deltaTime = (currentTime - lastTime) / 1_000_000_000f
                lastTime = currentTime
                
                // Cap delta to prevent spiral of death
                val safeDelta = deltaTime.coerceAtMost(0.25f)
                accumulator += safeDelta
                
                // Fixed timestep physics
                while (accumulator >= physicsStep) {
                    physicsWorld.step(physicsStep)
                    gameState.update(physicsStep)
                    accumulator -= physicsStep
                }
                
                // Render with interpolation
                val alpha = accumulator / physicsStep
                renderer.render(alpha)
                
                // Frame pacing
                val frameEnd = System.nanoTime()
                val sleepTime = frameTimeNs - (frameEnd - currentTime)
                if (sleepTime > 0) {
                    delay(sleepTime / 1_000_000) // Convert to ms for delay
                }
            }
        }
    }

    fun stop() {
        running = false
        scope.cancel()
    }
}

// Stubs for missing classes to avoid immediate IDE errors if possible
interface GameStateManager {
    fun update(dt: Float)
}
