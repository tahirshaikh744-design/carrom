package com.carrom.game.core.physics

import com.carrom.game.core.game.BoardConfig
import com.carrom.game.core.math.Vector2
import kotlin.math.sqrt
import kotlin.math.min
import kotlin.math.max

class PhysicsWorld(
    private val boardConfig: BoardConfig = BoardConfig.STANDARD
) {
    private val bodies = mutableListOf<RigidBody>()
    private val grid = SpatialHashGrid(bounds = boardConfig.bounds)
    
    // Collision manifold for precise contact resolution
    data class Manifold(
        val bodyA: RigidBody,
        val bodyB: RigidBody,
        val normal: Vector2,
        val penetration: Float,
        val contactPoint: Vector2
    )
    
    fun addBody(body: RigidBody) = bodies.add(body)
    fun removeBody(body: RigidBody) = bodies.remove(body)
    
    fun step(dt: Float) {
        // Wake sleeping bodies if disturbed
        bodies.forEach { body ->
            if (body.isSleeping && body.velocity.length > 0.5f) {
                body.isSleeping = false
            }
        }
        
        // Integrate motion
        bodies.filter { !it.isSleeping && !it.isPocketed }.forEach { body ->
            // Apply friction (exponential decay for natural feel)
            val frictionFactor = 1f - (body.friction * dt)
            body.velocity *= frictionFactor
            
            // Angular friction
            body.angularVelocity *= frictionFactor
            
            // Integrate position
            body.position += body.velocity * dt
            
            // Sleep threshold
            if (body.velocity.length < 0.3f && body.angularVelocity < 0.1f) {
                body.velocity = Vector2.ZERO
                body.angularVelocity = 0f
                body.isSleeping = true
            }
        }
        
        // Broad phase + Narrow phase
        grid.clear()
        bodies.filter { !it.isPocketed }.forEach { grid.insert(it) }
        
        val manifolds = mutableListOf<Manifold>()
        bodies.filter { !it.isPocketed }.forEach { bodyA ->
            grid.queryPotentialCollisions(bodyA).forEach { bodyB ->
                if (bodyA.id < bodyB.id) { // Avoid duplicates
                    detectCircleCircle(bodyA, bodyB)?.let { manifolds.add(it) }
                }
            }
        }
        
        // Wall collisions
        bodies.filter { !it.isPocketed }.forEach { body ->
            detectWallCollisions(body).forEach { manifolds.add(it) }
        }
        
        // Resolve collisions with iterative solver for stability
        repeat(8) { // 8 iterations for solid stacking
            manifolds.forEach { resolveCollision(it) }
        }
        
        // Pocket detection
        checkPockets()
    }
    
    private fun detectCircleCircle(a: RigidBody, b: RigidBody): Manifold? {
        val delta = b.position - a.position
        val distSq = delta.lengthSquared
        val minDist = a.radius + b.radius
        
        if (distSq >= minDist * minDist || distSq < 0.0001f) return null
        
        val dist = sqrt(distSq)
        val normal = delta / dist
        val penetration = minDist - dist
        
        return Manifold(
            bodyA = a,
            bodyB = b,
            normal = normal,
            penetration = penetration,
            contactPoint = a.position + normal * (a.radius - penetration * 0.5f)
        )
    }

    private fun detectWallCollisions(body: RigidBody): List<Manifold> {
        val bounds = boardConfig.bounds
        val manifolds = mutableListOf<Manifold>()
        
        // Left wall
        if (body.position.x - body.radius < bounds.left) {
            manifolds.add(Manifold(
                bodyA = body,
                bodyB = STATIC_BODY, // Dummy static body
                normal = Vector2(1f, 0f),
                penetration = bounds.left - (body.position.x - body.radius),
                contactPoint = Vector2(bounds.left, body.position.y)
            ))
        }
        // Right wall
        if (body.position.x + body.radius > bounds.right) {
            manifolds.add(Manifold(
                bodyA = body,
                bodyB = STATIC_BODY,
                normal = Vector2(-1f, 0f),
                penetration = (body.position.x + body.radius) - bounds.right,
                contactPoint = Vector2(bounds.right, body.position.y)
            ))
        }
        // Top wall
        if (body.position.y - body.radius < bounds.top) {
            manifolds.add(Manifold(
                bodyA = body,
                bodyB = STATIC_BODY,
                normal = Vector2(0f, 1f),
                penetration = bounds.top - (body.position.y - body.radius),
                contactPoint = Vector2(body.position.x, bounds.top)
            ))
        }
        // Bottom wall
        if (body.position.y + body.radius > bounds.bottom) {
            manifolds.add(Manifold(
                bodyA = body,
                bodyB = STATIC_BODY,
                normal = Vector2(0f, -1f),
                penetration = (body.position.y + body.radius) - bounds.bottom,
                contactPoint = Vector2(body.position.x, bounds.bottom)
            ))
        }
        
        return manifolds
    }
    
    private fun resolveCollision(m: Manifold) {
        val bodyA = m.bodyA
        val bodyB = m.bodyB
        
        val relativeVelocity = bodyB.velocity - bodyA.velocity
        val velAlongNormal = relativeVelocity.dot(m.normal)
        
        if (velAlongNormal > 0) return // Separating
        
        // Restitution (bounce)
        val e = min(bodyA.restitution, bodyB.restitution)
        
        // Calculate impulse
        val j = -(1f + e) * velAlongNormal / (bodyA.inverseMass + bodyB.inverseMass)
        val impulse = m.normal * j
        
        // Apply impulse
        bodyA.applyImpulse(-impulse, m.contactPoint - bodyA.position)
        bodyB.applyImpulse(impulse, m.contactPoint - bodyB.position)
        
        // Positional correction (prevent sinking)
        val percent = 0.4f // Penetration allowance percentage
        val slop = 0.01f // Penetration allowance
        val correction = m.normal * (max(m.penetration - slop, 0f) / 
            (bodyA.inverseMass + bodyB.inverseMass)) * percent
        
        bodyA.position -= correction * bodyA.inverseMass
        bodyB.position += correction * bodyB.inverseMass
    }
    
    private fun checkPockets() {
        bodies.filter { !it.isPocketed }.forEach { body ->
            boardConfig.pockets.forEach { pocket ->
                val dist = (body.position - pocket.position).length
                // Pocket slightly larger than puck for forgiving gameplay
                if (dist < pocket.radius * 0.85f) {
                    body.isPocketed = true
                    body.velocity = Vector2.ZERO
                }
            }
        }
    }

    companion object {
        // Shared static body for wall collisions
        private val STATIC_BODY = RigidBody(
            type = PuckType.Black, // Irrelevant for static
            mass = 0f, // Infinite mass
            restitution = 0.7f
        )
    }
}
